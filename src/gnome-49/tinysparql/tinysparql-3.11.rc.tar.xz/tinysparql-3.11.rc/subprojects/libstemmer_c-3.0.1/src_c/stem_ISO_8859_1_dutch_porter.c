/* Generated from dutch_porter.sbl by Snowball 3.0.1 - https://snowballstem.org/ */

#include "../runtime/header.h"

#ifdef __cplusplus
extern "C" {
#endif
extern int dutch_porter_ISO_8859_1_stem(struct SN_env * z);
#ifdef __cplusplus
}
#endif
static int r_standard_suffix(struct SN_env * z);
static int r_undouble(struct SN_env * z);
static int r_R2(struct SN_env * z);
static int r_R1(struct SN_env * z);
static int r_mark_regions(struct SN_env * z);
static int r_en_ending(struct SN_env * z);
static int r_e_ending(struct SN_env * z);
static int r_postlude(struct SN_env * z);
static int r_prelude(struct SN_env * z);
#ifdef __cplusplus
extern "C" {
#endif


extern struct SN_env * dutch_porter_ISO_8859_1_create_env(void);
extern void dutch_porter_ISO_8859_1_close_env(struct SN_env * z);


#ifdef __cplusplus
}
#endif
static const symbol s_0_1[1] = { 0xE1 };
static const symbol s_0_2[1] = { 0xE4 };
static const symbol s_0_3[1] = { 0xE9 };
static const symbol s_0_4[1] = { 0xEB };
static const symbol s_0_5[1] = { 0xED };
static const symbol s_0_6[1] = { 0xEF };
static const symbol s_0_7[1] = { 0xF3 };
static const symbol s_0_8[1] = { 0xF6 };
static const symbol s_0_9[1] = { 0xFA };
static const symbol s_0_10[1] = { 0xFC };
static const struct among a_0[11] = {
{ 0, 0, 0, 6, 0},
{ 1, s_0_1, -1, 1, 0},
{ 1, s_0_2, -2, 1, 0},
{ 1, s_0_3, -3, 2, 0},
{ 1, s_0_4, -4, 2, 0},
{ 1, s_0_5, -5, 3, 0},
{ 1, s_0_6, -6, 3, 0},
{ 1, s_0_7, -7, 4, 0},
{ 1, s_0_8, -8, 4, 0},
{ 1, s_0_9, -9, 5, 0},
{ 1, s_0_10, -10, 5, 0}
};

static const symbol s_1_1[1] = { 'I' };
static const symbol s_1_2[1] = { 'Y' };
static const struct among a_1[3] = {
{ 0, 0, 0, 3, 0},
{ 1, s_1_1, -1, 2, 0},
{ 1, s_1_2, -2, 1, 0}
};

static const symbol s_2_0[2] = { 'd', 'd' };
static const symbol s_2_1[2] = { 'k', 'k' };
static const symbol s_2_2[2] = { 't', 't' };
static const struct among a_2[3] = {
{ 2, s_2_0, 0, -1, 0},
{ 2, s_2_1, 0, -1, 0},
{ 2, s_2_2, 0, -1, 0}
};

static const symbol s_3_0[3] = { 'e', 'n', 'e' };
static const symbol s_3_1[2] = { 's', 'e' };
static const symbol s_3_2[2] = { 'e', 'n' };
static const symbol s_3_3[5] = { 'h', 'e', 'd', 'e', 'n' };
static const symbol s_3_4[1] = { 's' };
static const struct among a_3[5] = {
{ 3, s_3_0, 0, 2, 0},
{ 2, s_3_1, 0, 3, 0},
{ 2, s_3_2, 0, 2, 0},
{ 5, s_3_3, -1, 1, 0},
{ 1, s_3_4, 0, 3, 0}
};

static const symbol s_4_0[3] = { 'e', 'n', 'd' };
static const symbol s_4_1[2] = { 'i', 'g' };
static const symbol s_4_2[3] = { 'i', 'n', 'g' };
static const symbol s_4_3[4] = { 'l', 'i', 'j', 'k' };
static const symbol s_4_4[4] = { 'b', 'a', 'a', 'r' };
static const symbol s_4_5[3] = { 'b', 'a', 'r' };
static const struct among a_4[6] = {
{ 3, s_4_0, 0, 1, 0},
{ 2, s_4_1, 0, 2, 0},
{ 3, s_4_2, 0, 1, 0},
{ 4, s_4_3, 0, 3, 0},
{ 4, s_4_4, 0, 4, 0},
{ 3, s_4_5, 0, 5, 0}
};

static const symbol s_5_0[2] = { 'a', 'a' };
static const symbol s_5_1[2] = { 'e', 'e' };
static const symbol s_5_2[2] = { 'o', 'o' };
static const symbol s_5_3[2] = { 'u', 'u' };
static const struct among a_5[4] = {
{ 2, s_5_0, 0, -1, 0},
{ 2, s_5_1, 0, -1, 0},
{ 2, s_5_2, 0, -1, 0},
{ 2, s_5_3, 0, -1, 0}
};

static const unsigned char g_v[] = { 17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128 };

static const unsigned char g_v_I[] = { 1, 0, 0, 17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128 };

static const unsigned char g_v_j[] = { 17, 67, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128 };

static const symbol s_0[] = { 'a' };
static const symbol s_1[] = { 'e' };
static const symbol s_2[] = { 'i' };
static const symbol s_3[] = { 'o' };
static const symbol s_4[] = { 'u' };
static const symbol s_5[] = { 'Y' };
static const symbol s_6[] = { 'I' };
static const symbol s_7[] = { 'Y' };
static const symbol s_8[] = { 'y' };
static const symbol s_9[] = { 'i' };
static const symbol s_10[] = { 'g', 'e', 'm' };
static const symbol s_11[] = { 'h', 'e', 'i', 'd' };
static const symbol s_12[] = { 'h', 'e', 'i', 'd' };
static const symbol s_13[] = { 'e', 'n' };
static const symbol s_14[] = { 'i', 'g' };

static int r_prelude(struct SN_env * z) {
    int among_var;
    {
        int v_1 = z->c;
        while (1) {
            int v_2 = z->c;
            z->bra = z->c;
            if (z->c >= z->l || z->p[z->c + 0] >> 5 != 7 || !((340306450 >> (z->p[z->c + 0] & 0x1f)) & 1)) among_var = 6; else
            among_var = find_among(z, a_0, 11);
            z->ket = z->c;
            switch (among_var) {
                case 1:
                    {
                        int ret = slice_from_s(z, 1, s_0);
                        if (ret < 0) return ret;
                    }
                    break;
                case 2:
                    {
                        int ret = slice_from_s(z, 1, s_1);
                        if (ret < 0) return ret;
                    }
                    break;
                case 3:
                    {
                        int ret = slice_from_s(z, 1, s_2);
                        if (ret < 0) return ret;
                    }
                    break;
                case 4:
                    {
                        int ret = slice_from_s(z, 1, s_3);
                        if (ret < 0) return ret;
                    }
                    break;
                case 5:
                    {
                        int ret = slice_from_s(z, 1, s_4);
                        if (ret < 0) return ret;
                    }
                    break;
                case 6:
                    if (z->c >= z->l) goto lab0;
                    z->c++;
                    break;
            }
            continue;
        lab0:
            z->c = v_2;
            break;
        }
        z->c = v_1;
    }
    {
        int v_3 = z->c;
        z->bra = z->c;
        if (z->c == z->l || z->p[z->c] != 'y') { z->c = v_3; goto lab1; }
        z->c++;
        z->ket = z->c;
        {
            int ret = slice_from_s(z, 1, s_5);
            if (ret < 0) return ret;
        }
    lab1:
        ;
    }
    while (1) {
        int v_4 = z->c;
        {
            int ret = out_grouping(z, g_v, 97, 232, 1);
            if (ret < 0) goto lab2;
            z->c += ret;
        }
        {
            int v_5 = z->c;
            z->bra = z->c;
            {
                int v_6 = z->c;
                if (z->c == z->l || z->p[z->c] != 'i') goto lab5;
                z->c++;
                z->ket = z->c;
                {
                    int v_7 = z->c;
                    if (in_grouping(z, g_v, 97, 232, 0)) goto lab6;
                    {
                        int ret = slice_from_s(z, 1, s_6);
                        if (ret < 0) return ret;
                    }
                lab6:
                    z->c = v_7;
                }
                goto lab4;
            lab5:
                z->c = v_6;
                if (z->c == z->l || z->p[z->c] != 'y') { z->c = v_5; goto lab3; }
                z->c++;
                z->ket = z->c;
                {
                    int ret = slice_from_s(z, 1, s_7);
                    if (ret < 0) return ret;
                }
            }
        lab4:
        lab3:
            ;
        }
        continue;
    lab2:
        z->c = v_4;
        break;
    }
    return 1;
}

static int r_mark_regions(struct SN_env * z) {
    z->I[2] = z->l;
    z->I[1] = z->l;
    {
        int v_1 = z->c;
z->c = z->c + 3;
        if (z->c > z->l) return 0;
        z->I[0] = z->c;
        z->c = v_1;
    }
    {
        int ret = out_grouping(z, g_v, 97, 232, 1);
        if (ret < 0) return 0;
        z->c += ret;
    }
    {
        int ret = in_grouping(z, g_v, 97, 232, 1);
        if (ret < 0) return 0;
        z->c += ret;
    }
    z->I[2] = z->c;
    if (z->I[2] >= z->I[0]) goto lab0;
    z->I[2] = z->I[0];
lab0:
    {
        int ret = out_grouping(z, g_v, 97, 232, 1);
        if (ret < 0) return 0;
        z->c += ret;
    }
    {
        int ret = in_grouping(z, g_v, 97, 232, 1);
        if (ret < 0) return 0;
        z->c += ret;
    }
    z->I[1] = z->c;
    return 1;
}

static int r_postlude(struct SN_env * z) {
    int among_var;
    while (1) {
        int v_1 = z->c;
        z->bra = z->c;
        if (z->c >= z->l || (z->p[z->c + 0] != 73 && z->p[z->c + 0] != 89)) among_var = 3; else
        among_var = find_among(z, a_1, 3);
        z->ket = z->c;
        switch (among_var) {
            case 1:
                {
                    int ret = slice_from_s(z, 1, s_8);
                    if (ret < 0) return ret;
                }
                break;
            case 2:
                {
                    int ret = slice_from_s(z, 1, s_9);
                    if (ret < 0) return ret;
                }
                break;
            case 3:
                if (z->c >= z->l) goto lab0;
                z->c++;
                break;
        }
        continue;
    lab0:
        z->c = v_1;
        break;
    }
    return 1;
}

static int r_R1(struct SN_env * z) {
    return z->I[2] <= z->c;
}

static int r_R2(struct SN_env * z) {
    return z->I[1] <= z->c;
}

static int r_undouble(struct SN_env * z) {
    {
        int v_1 = z->l - z->c;
        if (z->c - 1 <= z->lb || z->p[z->c - 1] >> 5 != 3 || !((1050640 >> (z->p[z->c - 1] & 0x1f)) & 1)) return 0;
        if (!find_among_b(z, a_2, 3)) return 0;
        z->c = z->l - v_1;
    }
    z->ket = z->c;
    if (z->c <= z->lb) return 0;
    z->c--;
    z->bra = z->c;
    {
        int ret = slice_del(z);
        if (ret < 0) return ret;
    }
    return 1;
}

static int r_e_ending(struct SN_env * z) {
    z->I[3] = 0;
    z->ket = z->c;
    if (z->c <= z->lb || z->p[z->c - 1] != 'e') return 0;
    z->c--;
    z->bra = z->c;
    {
        int ret = r_R1(z);
        if (ret <= 0) return ret;
    }
    {
        int v_1 = z->l - z->c;
        if (out_grouping_b(z, g_v, 97, 232, 0)) return 0;
        z->c = z->l - v_1;
    }
    {
        int ret = slice_del(z);
        if (ret < 0) return ret;
    }
    z->I[3] = 1;
    {
        int ret = r_undouble(z);
        if (ret <= 0) return ret;
    }
    return 1;
}

static int r_en_ending(struct SN_env * z) {
    {
        int ret = r_R1(z);
        if (ret <= 0) return ret;
    }
    {
        int v_1 = z->l - z->c;
        if (out_grouping_b(z, g_v, 97, 232, 0)) return 0;
        z->c = z->l - v_1;
        {
            int v_2 = z->l - z->c;
            if (!(eq_s_b(z, 3, s_10))) goto lab0;
            return 0;
        lab0:
            z->c = z->l - v_2;
        }
    }
    {
        int ret = slice_del(z);
        if (ret < 0) return ret;
    }
    {
        int ret = r_undouble(z);
        if (ret <= 0) return ret;
    }
    return 1;
}

static int r_standard_suffix(struct SN_env * z) {
    int among_var;
    {
        int v_1 = z->l - z->c;
        z->ket = z->c;
        if (z->c <= z->lb || z->p[z->c - 1] >> 5 != 3 || !((540704 >> (z->p[z->c - 1] & 0x1f)) & 1)) goto lab0;
        among_var = find_among_b(z, a_3, 5);
        if (!among_var) goto lab0;
        z->bra = z->c;
        switch (among_var) {
            case 1:
                {
                    int ret = r_R1(z);
                    if (ret == 0) goto lab0;
                    if (ret < 0) return ret;
                }
                {
                    int ret = slice_from_s(z, 4, s_11);
                    if (ret < 0) return ret;
                }
                break;
            case 2:
                {
                    int ret = r_en_ending(z);
                    if (ret == 0) goto lab0;
                    if (ret < 0) return ret;
                }
                break;
            case 3:
                {
                    int ret = r_R1(z);
                    if (ret == 0) goto lab0;
                    if (ret < 0) return ret;
                }
                if (out_grouping_b(z, g_v_j, 97, 232, 0)) goto lab0;
                {
                    int ret = slice_del(z);
                    if (ret < 0) return ret;
                }
                break;
        }
    lab0:
        z->c = z->l - v_1;
    }
    {
        int v_2 = z->l - z->c;
        {
            int ret = r_e_ending(z);
            if (ret < 0) return ret;
        }
        z->c = z->l - v_2;
    }
    {
        int v_3 = z->l - z->c;
        z->ket = z->c;
        if (!(eq_s_b(z, 4, s_12))) goto lab1;
        z->bra = z->c;
        {
            int ret = r_R2(z);
            if (ret == 0) goto lab1;
            if (ret < 0) return ret;
        }
        {
            int v_4 = z->l - z->c;
            if (z->c <= z->lb || z->p[z->c - 1] != 'c') goto lab2;
            z->c--;
            goto lab1;
        lab2:
            z->c = z->l - v_4;
        }
        {
            int ret = slice_del(z);
            if (ret < 0) return ret;
        }
        z->ket = z->c;
        if (!(eq_s_b(z, 2, s_13))) goto lab1;
        z->bra = z->c;
        {
            int ret = r_en_ending(z);
            if (ret == 0) goto lab1;
            if (ret < 0) return ret;
        }
    lab1:
        z->c = z->l - v_3;
    }
    {
        int v_5 = z->l - z->c;
        z->ket = z->c;
        if (z->c - 1 <= z->lb || z->p[z->c - 1] >> 5 != 3 || !((264336 >> (z->p[z->c - 1] & 0x1f)) & 1)) goto lab3;
        among_var = find_among_b(z, a_4, 6);
        if (!among_var) goto lab3;
        z->bra = z->c;
        switch (among_var) {
            case 1:
                {
                    int ret = r_R2(z);
                    if (ret == 0) goto lab3;
                    if (ret < 0) return ret;
                }
                {
                    int ret = slice_del(z);
                    if (ret < 0) return ret;
                }
                {
                    int v_6 = z->l - z->c;
                    z->ket = z->c;
                    if (!(eq_s_b(z, 2, s_14))) goto lab5;
                    z->bra = z->c;
                    {
                        int ret = r_R2(z);
                        if (ret == 0) goto lab5;
                        if (ret < 0) return ret;
                    }
                    {
                        int v_7 = z->l - z->c;
                        if (z->c <= z->lb || z->p[z->c - 1] != 'e') goto lab6;
                        z->c--;
                        goto lab5;
                    lab6:
                        z->c = z->l - v_7;
                    }
                    {
                        int ret = slice_del(z);
                        if (ret < 0) return ret;
                    }
                    goto lab4;
                lab5:
                    z->c = z->l - v_6;
                    {
                        int ret = r_undouble(z);
                        if (ret == 0) goto lab3;
                        if (ret < 0) return ret;
                    }
                }
            lab4:
                break;
            case 2:
                {
                    int ret = r_R2(z);
                    if (ret == 0) goto lab3;
                    if (ret < 0) return ret;
                }
                {
                    int v_8 = z->l - z->c;
                    if (z->c <= z->lb || z->p[z->c - 1] != 'e') goto lab7;
                    z->c--;
                    goto lab3;
                lab7:
                    z->c = z->l - v_8;
                }
                {
                    int ret = slice_del(z);
                    if (ret < 0) return ret;
                }
                break;
            case 3:
                {
                    int ret = r_R2(z);
                    if (ret == 0) goto lab3;
                    if (ret < 0) return ret;
                }
                {
                    int ret = slice_del(z);
                    if (ret < 0) return ret;
                }
                {
                    int ret = r_e_ending(z);
                    if (ret == 0) goto lab3;
                    if (ret < 0) return ret;
                }
                break;
            case 4:
                {
                    int ret = r_R2(z);
                    if (ret == 0) goto lab3;
                    if (ret < 0) return ret;
                }
                {
                    int ret = slice_del(z);
                    if (ret < 0) return ret;
                }
                break;
            case 5:
                {
                    int ret = r_R2(z);
                    if (ret == 0) goto lab3;
                    if (ret < 0) return ret;
                }
                if (!(z->I[3])) goto lab3;
                {
                    int ret = slice_del(z);
                    if (ret < 0) return ret;
                }
                break;
        }
    lab3:
        z->c = z->l - v_5;
    }
    {
        int v_9 = z->l - z->c;
        if (out_grouping_b(z, g_v_I, 73, 232, 0)) goto lab8;
        {
            int v_10 = z->l - z->c;
            if (z->c - 1 <= z->lb || z->p[z->c - 1] >> 5 != 3 || !((2129954 >> (z->p[z->c - 1] & 0x1f)) & 1)) goto lab8;
            if (!find_among_b(z, a_5, 4)) goto lab8;
            if (out_grouping_b(z, g_v, 97, 232, 0)) goto lab8;
            z->c = z->l - v_10;
        }
        z->ket = z->c;
        if (z->c <= z->lb) goto lab8;
        z->c--;
        z->bra = z->c;
        {
            int ret = slice_del(z);
            if (ret < 0) return ret;
        }
    lab8:
        z->c = z->l - v_9;
    }
    return 1;
}

extern int dutch_porter_ISO_8859_1_stem(struct SN_env * z) {
    {
        int v_1 = z->c;
        {
            int ret = r_prelude(z);
            if (ret < 0) return ret;
        }
        z->c = v_1;
    }
    {
        int v_2 = z->c;
        {
            int ret = r_mark_regions(z);
            if (ret < 0) return ret;
        }
        z->c = v_2;
    }
    z->lb = z->c; z->c = z->l;
    {
        int ret = r_standard_suffix(z);
        if (ret < 0) return ret;
    }
    z->c = z->lb;
    {
        int v_3 = z->c;
        {
            int ret = r_postlude(z);
            if (ret < 0) return ret;
        }
        z->c = v_3;
    }
    return 1;
}

extern struct SN_env * dutch_porter_ISO_8859_1_create_env(void) { return SN_create_env(0, 4); }

extern void dutch_porter_ISO_8859_1_close_env(struct SN_env * z) { SN_close_env(z, 0); }

