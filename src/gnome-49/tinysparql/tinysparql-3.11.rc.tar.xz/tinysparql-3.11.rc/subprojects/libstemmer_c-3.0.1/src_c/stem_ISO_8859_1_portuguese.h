/* Generated from portuguese.sbl by Snowball 3.0.1 - https://snowballstem.org/ */

#ifdef __cplusplus
extern "C" {
#endif

extern struct SN_env * portuguese_ISO_8859_1_create_env(void);
extern void portuguese_ISO_8859_1_close_env(struct SN_env * z);

extern int portuguese_ISO_8859_1_stem(struct SN_env * z);

#ifdef __cplusplus
}
#endif

