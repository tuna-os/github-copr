<?php
	phpinfo ();
?>